import random
import gym
from gym import spaces
import numpy as np
from tqdm import tqdm
import torch
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
import collections
import numpy as np
import time
from numpy.testing import assert_equal
from scipy.integrate import complex_ode
#from scipy.stats import kurtosis
from scipy.stats import moment
from gym.envs.registration import register
register(id='envNPR-v0',
         entry_point='envNPR:LaserSimulationEnv', )


def laser_simulation(uvt, alpha1, alpha2, alpha3, alphap, K):
    # parameters of the Maxwell equation
    """
    D = 1
    K = 0.1
    E0 = 1
    tau = 0.1
    g0 = 0.3
    Gamma = 0.2
    """
    D = -0.4
    E0 = 4.23
    tau = 0.1
    g0 = 1.73
    Gamma = 0.1

    Z = 1.5  # cavity length
    T = 60
    n = 256  # t slices
    Rnd = 500  # round trips
    t2 = np.linspace(-T / 2, T / 2, n + 1)
    t_dis = t2[0:n].reshape([1, n])  # time discretization
    new = np.concatenate((np.linspace(0, n // 2 - 1, n // 2),
                          np.linspace(-n // 2, -1, n // 2)), 0)
    k = (2 * np.pi / T) * new
    ts = []
    ys = []
    t0 = 0.0
    tend = 1

    # waveplates & polarizer
    W4 = np.array([[np.exp(-1j * np.pi / 4), 0], [0, np.exp(1j * np.pi / 4)]]);  # quarter waveplate
    W2 = np.array([[-1j, 0], [0, 1j]]);  # half waveplate
    WP = np.array([[1, 0], [0, 0]]);  # polarizer

    # waveplate settings
    R1 = np.array([[np.cos(alpha1), -np.sin(alpha1)],
                   [np.sin(alpha1), np.cos(alpha1)]])
    R2 = np.array([[np.cos(alpha2), -np.sin(alpha2)],
                   [np.sin(alpha2), np.cos(alpha2)]])
    R3 = np.array([[np.cos(alpha3), -np.sin(alpha3)],
                   [np.sin(alpha3), np.cos(alpha3)]])
    RP = np.array([[np.cos(alphap), -np.sin(alphap)],
                   [np.sin(alphap), np.cos(alphap)]])
    J1 = np.matmul(np.matmul(R1, W4), np.transpose(R1))
    J2 = np.matmul(np.matmul(R2, W4), np.transpose(R2))
    J3 = np.matmul(np.matmul(R3, W2), np.transpose(R3))
    JP = np.matmul(np.matmul(RP, WP), np.transpose(RP))

    # transfer function
    Transf = np.matmul(np.matmul(np.matmul(J1, JP), J2), J3)

    urnd = np.zeros([Rnd, n], dtype=complex)
    vrnd = np.zeros([Rnd, n], dtype=complex)
    t_dis = t_dis.reshape(n, )
    energy = np.zeros([1, Rnd])

    # definition of the rhs of the ode
    def mlock_CNLS_rhs(ts, uvt):
        [ut_rhs, vt_rhs] = np.split(uvt, 2)
        u = np.fft.ifft(ut_rhs)
        v = np.fft.ifft(vt_rhs)
        # calculation of the energy function
        E = np.trapz(np.conj(u) * u + np.conj(v) * v, t_dis)

        # u of the rhs
        urhs = -1j * 0.5 * D * (k ** 2) * ut_rhs - 1j * K * ut_rhs + \
               1j * np.fft.fft((np.conj(u) * u + (2 / 3) * np.conj(v) * v) * u + \
                               (1 / 3) * (v ** 2) * np.conj(u)) + \
               2 * g0 / (1 + E / E0) * (1 - tau * (k ** 2)) * ut_rhs - Gamma * ut_rhs

        # v of the rhs
        vrhs = -1j * 0.5 * D * (k ** 2) * vt_rhs + 1j * K * vt_rhs + \
               1j * np.fft.fft((np.conj(v) * v + (2 / 3) * np.conj(u) * u) * v + \
                               (1 / 3) * (u ** 2) * np.conj(v)) + \
               2 * g0 / (1 + E / E0) * (1 - tau * (k ** 2)) * vt_rhs - Gamma * vt_rhs

        return np.concatenate((urhs, vrhs), axis=0)

    # definition of the solution output for the ode integration
    def solout(t, y):
        ts.append(t)
        ys.append(y.copy())

    start = time.time()

    uv_list = []
    norms = []
    change_norm = 100
    jrnd = 0
    # solving the ode for Rnd rounds
    while (jrnd < Rnd and change_norm > 1e-6):
        ts = []
        ys = []

        t0 = Z * jrnd
        tend = Z * (jrnd + 1)

        uvtsol = complex_ode(mlock_CNLS_rhs)
        uvtsol.set_integrator(method='adams', name='dop853')  # alternative 'dopri5'
        uvtsol.set_solout(solout)
        uvtsol.set_initial_value(uvt, t0)
        sol = uvtsol.integrate(tend)
        assert_equal(ts[0], t0)
        assert_equal(ts[-1], tend)

        u = np.fft.ifft(sol[0:n])
        v = np.fft.ifft(sol[n:2 * n])

        urnd[jrnd, :] = u
        vrnd[jrnd, :] = v
        energy[0, jrnd] = np.trapz(np.abs(u) ** 2 + np.abs(v) ** 2, t_dis)

        uvplus = np.matmul(Transf, np.transpose(np.concatenate((u.reshape(n, 1),
                                                                v.reshape(n, 1)), axis=1)))
        uv_list.append(np.concatenate((uvplus[0, :],
                                       uvplus[1, :]), axis=0))

        uvt = np.concatenate((np.fft.fft(uvplus[0, :]),
                              np.fft.fft(uvplus[1, :])), axis=0)

        if jrnd > 0:
            phi = np.sqrt(np.abs(np.vstack(uv_list)[:, :n]) ** 2 + \
                          np.abs(np.vstack(uv_list)[:, n:2 * n]) ** 2)
            change_norm = np.linalg.norm((phi[-1, :] - phi[len(phi) - 2, :])) / \
                          np.linalg.norm(phi[len(phi) - 2, :])
            norms.append(change_norm)

        jrnd += 1

    kur = np.abs(np.fft.fftshift(np.fft.fft(phi[-1, :])))
    # M4 = kurtosis(kur)
    M4 = moment(kur, 4) / np.std(kur) ** 4

    end = time.time()
    print(end - start)

    E = np.sqrt(np.trapz(phi[-1, :] ** 2, t_dis))

    states = np.array([E, M4, alpha1, alpha2, alpha3, alphap])
    return (uvt,states)

def sech(x):
    # definition of the sech-function
    return np.cosh(x)**(-1)


class LaserSimulationEnv(gym.Env):
    def __init__(self):
        super(LaserSimulationEnv, self).__init__()

        # Define the observation space
        self.observation_space = spaces.Box(low=-np.pi / 2, high=np.pi / 2, shape=(4,), dtype=np.float32)

        # Define the action space
        self.action_space = spaces.Box(low=-1, high=1, shape=(4,), dtype=np.float32)

        # Define the action space low and high values

        # Other initialization code...
        alpha1 = -15 * np.pi / 180
        alpha2 = -5 * np.pi / 180
        alpha3 = 20 * np.pi / 180
        alphap = 84 * np.pi / 180
        self.state = [alpha1, alpha2, alpha3, alphap]
        self.steps = 0
        self.total_reward = 0

    def step(self, action):

        action1 = action[0] * np.pi / 90
        action2 = action[1] * np.pi / 90
        action3 = action[2] * np.pi / 90
        action4 = action[3] * np.pi / 90

        print(action[0], action[1], action[2], action[3])
        self.state[0] += action1
        while self.state[0] > np.pi / 2:
            self.state[0] -= np.pi
        while self.state[0] < -np.pi / 2:
            self.state[0] += np.pi

        a = self.state[0]

        self.state[1] += action2
        while self.state[1] > np.pi / 2:
            self.state[1] -= np.pi
        while self.state[1] < -np.pi / 2:
            self.state[1] += np.pi

        b = self.state[1]

        self.state[2] += action3
        while self.state[2] > np.pi / 2:
            self.state[2] -= np.pi
        while self.state[2] < -np.pi / 2:
            self.state[2] += np.pi

        c = self.state[2]

        self.state[3] += action4
        while self.state[3] > np.pi / 2:
            self.state[3] -= np.pi
        while self.state[3] < -np.pi / 2:
            self.state[3] += np.pi

        d = self.state[3]



        T = 60
        n = 256
        t2 = np.linspace(-T / 2, T / 2, n + 1)
        t_dis = t2[0:n].reshape([1, n])
        u = 0.5 * np.reshape(sech(t_dis / 2), [n, ])  # orthogonally polarized electric field
        v = 0.5 * np.reshape(sech(t_dis / 2), [n, ])  # envelopes in the optical fiber

        ut = np.fft.fft(u).reshape(n, )  # fast fourier transformation of the
        vt = np.fft.fft(v).reshape(n, )  # electrical fields
        uvt = np.concatenate([ut, vt], axis=0)  # concatenation of ut and vt
        (uvt_cur, states) = laser_simulation(uvt, a, b, c, d, 0.1)
        x = states[0] / states[1] - 0.1
        # Calculate the reward and done flag (modify as needed)
        reward = x
        print('Laser states: %s, reward: %s' % (', '.join(map(str, states)), x + 0.1))
        # print('Laser states: %s, reward: %s' % (states, states[0]/states[1]))
        with open('output.txt', 'a') as f:
            # f.write('Laser states: %s, reward: %s\n' % (states, states[0]/states[1]))
            f.write('Laser states: %s, reward: %s\n' % (', '.join(map(str, states)), x + 0.1))
        self.steps += 1
        self.total_reward = reward + 0.1 + self.total_reward
        if self.steps >= 30:
            done = True
            with open('total_rewards.txt', 'a') as f:
                f.write('Total reward for episode: %s\n' % self.total_reward)
            self.total_reward = 0
            self.steps = 0
            self.state = [-15 * np.pi / 180, -5 * np.pi / 180, 20 * np.pi / 180, 84 * np.pi / 180]
        else:
            done = False

        # Return the observation, reward, done flag, and additional info
        observation = np.array([a, b, c, d], dtype=np.float32)
        return observation, reward, done, {}

    def seed(self, seed=None):
        np.random.seed(seed)

    def reset(self):

        a1 = -15 * np.pi / 180
        a2 = -5 * np.pi / 180
        a3 = 20 * np.pi / 180
        ap = 84 * np.pi / 180

        self.state = [a1, a2, a3, ap]


        observation = np.array([a1, a2, a3, ap], dtype=np.float32)
        return observation

    def render(self, mode='human'):

        return None

    def close(self):

        return None

env = LaserSimulationEnv()


observation_space = env.observation_space
action_space = env.action_space

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = collections.deque(maxlen=capacity)

    def add(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return np.array(state), action, reward, np.array(next_state), done

    def size(self):
        return len(self.buffer)

def moving_average(a, window_size):
    cumulative_sum = np.cumsum(np.insert(a, 0, 0))
    middle = (cumulative_sum[window_size:] - cumulative_sum[:-window_size]) / window_size
    r = np.arange(1, window_size-1, 2)
    begin = np.cumsum(a[:window_size-1])[::2] / r
    end = (np.cumsum(a[:-window_size:-1])[::2] / r)[::-1]
    return np.concatenate((begin, middle, end))

def train_on_policy_agent(env, agent, num_episodes):
    return_list = []
    for i in range(10):
        with tqdm(total=int(num_episodes/10), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes/10)):
                episode_return = 0
                transition_dict = {'states': [], 'actions': [], 'next_states': [], 'rewards': [], 'dones': []}
                state = env.reset()
                done = False
                while not done:
                    action = agent.take_action(state)
                    next_state, reward, done, _ = env.step(action)
                    transition_dict['states'].append(state)
                    transition_dict['actions'].append(action)
                    transition_dict['next_states'].append(next_state)
                    transition_dict['rewards'].append(reward)
                    transition_dict['dones'].append(done)
                    state = next_state
                    episode_return += reward
                return_list.append(episode_return)
                agent.update(transition_dict)
                if (i_episode+1) % 10 == 0:
                    pbar.set_postfix({'episode': '%d' % (num_episodes/10 * i + i_episode+1), 'return': '%.3f' % np.mean(return_list[-10:])})
                pbar.update(1)
    return return_list

def train_off_policy_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size):
    return_list = []
    for i in range(10):
        with tqdm(total=int(num_episodes/10), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes/10)):
                episode_return = 0
                state = env.reset()
                done = False
                while not done:
                    action = agent.take_action(state)

                    next_state, reward, done, _ = env.step(action)
                    replay_buffer.add(state, action, reward, next_state, done)
                    state = next_state
                    episode_return += reward
                    if replay_buffer.size() > minimal_size:
                        b_s, b_a, b_r, b_ns, b_d = replay_buffer.sample(batch_size)
                        transition_dict = {
                            'states': b_s,
                            'actions': b_a,
                            'next_states': b_ns,
                            'rewards': b_r,
                            'dones': b_d
                        }
                        agent.update(transition_dict)
                return_list.append(episode_return)
                if (i_episode+1) % 10 == 0:
                    pbar.set_postfix({
                        'episode': '%d' % (num_episodes/10 * i + i_episode+1),
                        'return': '%.3f' % np.mean(return_list[-10:])
                    })
                pbar.update(1)
    return return_list



def compute_advantage(gamma, lmbda, td_delta):
    td_delta = td_delta.detach().numpy()
    advantage_list = []
    advantage = 0.0
    for delta in td_delta[::-1]:
        advantage = gamma * lmbda * advantage + delta
        advantage_list.append(advantage)
    advantage_list.reverse()
    return torch.tensor(advantage_list, dtype=torch.float)



class PolicyNetContinuous(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim, action_bound):
        super(PolicyNetContinuous, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc_mu = torch.nn.Linear(hidden_dim, action_dim)
        self.fc_std = torch.nn.Linear(hidden_dim, action_dim)
        self.action_bound = action_bound

    def forward(self, x):
        x = F.relu(self.fc1(x))
        mu = self.fc_mu(x)
        std = F.softplus(self.fc_std(x))
        dist = Normal(mu, std)
        normal_sample = dist.rsample()
        log_prob = dist.log_prob(normal_sample)
        action = torch.tanh(normal_sample)
        log_prob -= torch.log(1 - torch.tanh(action).pow(2) + 1e-7)
        action = action * self.action_bound
        return action, log_prob


class QValueNetContinuous(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(QValueNetContinuous, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim + action_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc_out = torch.nn.Linear(hidden_dim, 1)

    def forward(self, x, a):
        cat = torch.cat([x, a], dim=1)
        x = F.relu(self.fc1(cat))
        x = F.relu(self.fc2(x))
        return self.fc_out(x)


class SACContinuous:


    def __init__(self, state_dim, hidden_dim, action_dim, action_bound,
                 actor_lr, critic_lr, alpha_lr, target_entropy, tau, gamma,
                 device):
        self.actor = PolicyNetContinuous(state_dim, hidden_dim, action_dim,
                                         action_bound).to(device)
        self.critic_1 = QValueNetContinuous(state_dim, hidden_dim,
                                            action_dim).to(device)
        self.critic_2 = QValueNetContinuous(state_dim, hidden_dim,
                                            action_dim).to(device)
        self.target_critic_1 = QValueNetContinuous(state_dim,
                                                   hidden_dim, action_dim).to(
            device)
        self.target_critic_2 = QValueNetContinuous(state_dim,
                                                   hidden_dim, action_dim).to(
            device)

        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),
                                                lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(),
                                                   lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(),
                                                   lr=critic_lr)

        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha.requires_grad = True
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha],
                                                    lr=alpha_lr)
        self.target_entropy = target_entropy
        self.gamma = gamma
        self.tau = tau
        self.device = device

    def take_action(self, state):
        state = torch.tensor(state, dtype=torch.float).to(self.device)
        action = self.actor(state)[0]
        return action.detach().cpu().numpy()

    def calc_target(self, rewards, next_states, dones):
        next_actions, log_prob = self.actor(next_states)
        entropy = -log_prob
        q1_value = self.target_critic_1(next_states, next_actions)
        q2_value = self.target_critic_2(next_states, next_actions)
        next_value = torch.min(q1_value,
                               q2_value) + self.log_alpha.exp() * entropy
        td_target = rewards + self.gamma * next_value * (1 - dones)
        return td_target

    def soft_update(self, net, target_net):
        for param_target, param in zip(target_net.parameters(),
                                       net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) +
                                    param.data * self.tau)

    def update(self, transition_dict):
        states = torch.tensor(transition_dict['states'],
                              dtype=torch.float).to(self.device)
        actions = torch.tensor(transition_dict['actions'],
                               dtype=torch.float).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'],
                               dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'],
                                   dtype=torch.float).to(self.device)
        dones = torch.tensor(transition_dict['dones'],
                             dtype=torch.float).view(-1, 1).to(self.device)


        td_target = self.calc_target(rewards, next_states, dones)
        critic_1_loss = torch.mean(
            F.mse_loss(self.critic_1(states, actions), td_target.detach()))
        critic_2_loss = torch.mean(
            F.mse_loss(self.critic_2(states, actions), td_target.detach()))
        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward()
        self.critic_1_optimizer.step()
        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward()
        self.critic_2_optimizer.step()


        new_actions, log_prob = self.actor(states)
        entropy = -log_prob
        q1_value = self.critic_1(states, new_actions)
        q2_value = self.critic_2(states, new_actions)
        actor_loss = torch.mean(-self.log_alpha.exp() * entropy -
                                torch.min(q1_value, q2_value))
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()


        alpha_loss = torch.mean(
            (entropy - self.target_entropy).detach() * self.log_alpha.exp())
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.log_alpha_optimizer.step()

        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)




actor_lr = 1e-4
critic_lr = 1e-3
alpha_lr = 1e-4
num_episodes = 600
hidden_dim = 128
gamma = 0.99

tau = 0.005
buffer_size = 20000
minimal_size = 6000
batch_size = 16

device = torch.device("cuda") if torch.cuda.is_available() else torch.device(
    "cpu")

env_name = 'envNPR-v0'

state_dim = env.observation_space.shape[0]
action_dim = env.action_space.shape[0]
action_bound = env.action_space.high[0]
random.seed(0)
np.random.seed(0)
env.seed(0)
torch.manual_seed(0)
target_entropy = -4
replay_buffer = ReplayBuffer(buffer_size)

agent = SACContinuous(state_dim, hidden_dim, action_dim, action_bound, actor_lr, critic_lr, alpha_lr,
                      target_entropy, tau, gamma, device)

return_list = train_off_policy_agent(env, agent, num_episodes,
                                              replay_buffer, minimal_size,
                                              batch_size)

episodes_list = list(range(len(return_list)))
plt.plot(episodes_list, return_list)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('SAC on {}'.format(env_name))
plt.show()

mv_return = moving_average(return_list, 9)

plt.plot(episodes_list, mv_return)
plt.xlabel('Episodes')
plt.ylabel('Returns')
plt.title('SAC on {}'.format(env_name))
plt.show()

torch.save(agent.actor.state_dict(), 'agent_actor.pth')
torch.save(agent.critic_1.state_dict(), 'agent_critic_1.pth')
torch.save(agent.critic_2.state_dict(), 'agent_critic_2.pth')
torch.save(agent.target_critic_1.state_dict(), 'agent_target_critic_1.pth')
torch.save(agent.target_critic_2.state_dict(), 'agent_target_critic_2.pth')
torch.save(agent.log_alpha, 'agent_log_alpha.pth')

