import random
import gym
import argparse
from gym import spaces
import numpy as np
from tqdm import tqdm
import torch as T
import torch.nn.functional as F
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal
import matplotlib.pyplot as plt
import collections
import numpy as np
import time
import os
from numpy.testing import assert_equal
from scipy.integrate import complex_ode
#from scipy.stats import kurtosis
from scipy.stats import moment
from gym.envs.registration import register

register(id='envNPR-v0',
    entry_point='envNPR:LaserSimulationEnv',)

parser = argparse.ArgumentParser()
parser.add_argument('--max_episodes', type=int, default=1000)
parser.add_argument('--ckpt_dir', type=str, default='./checkpoints/TD3/')


args = parser.parse_args()

device = T.device("cuda:0" if T.cuda.is_available() else "cpu")

def create_directory(path: str, sub_path_list: list):
    for sub_path in sub_path_list:
        if not os.path.exists(path + sub_path):
            os.makedirs(path + sub_path, exist_ok=True)
            print('Path: {} create successfully!'.format(path + sub_path))
        else:
            print('Path: {} is already existence!'.format(path + sub_path))


def plot_learning_curve(episodes, records, title, ylabel, figure_file):
    plt.figure()
    plt.plot(episodes, records, color='b', linestyle='-')
    plt.title(title)
    plt.xlabel('episode')
    plt.ylabel(ylabel)

    plt.show()
    plt.savefig(figure_file)


def scale_action(action, low, high):
    action = np.clip(action, -1, 1)
    weight = (high - low) / 2
    bias = (high + low) / 2
    action_ = action * weight + bias

    return action_


def laser_simulation(uvt, alpha1, alpha2, alpha3, alphap, K):
    # parameters of the Maxwell equation

    D = -0.4
    E0 = 4.23
    tau = 0.1
    g0 = 1.73
    Gamma = 0.1

    Z = 1.5  # cavity length
    T = 60
    n = 256  # t slices
    Rnd = 500  # round trips
    t2 = np.linspace(-T / 2, T / 2, n + 1)
    t_dis = t2[0:n].reshape([1, n])  # time discretization
    new = np.concatenate((np.linspace(0, n // 2 - 1, n // 2),
                          np.linspace(-n // 2, -1, n // 2)), 0)
    k = (2 * np.pi / T) * new
    ts = []
    ys = []
    t0 = 0.0
    tend = 1

    # waveplates & polarizer
    W4 = np.array([[np.exp(-1j * np.pi / 4), 0], [0, np.exp(1j * np.pi / 4)]]);  # quarter waveplate
    W2 = np.array([[-1j, 0], [0, 1j]]);  # half waveplate
    WP = np.array([[1, 0], [0, 0]]);  # polarizer

    # waveplate settings
    R1 = np.array([[np.cos(alpha1), -np.sin(alpha1)],
                   [np.sin(alpha1), np.cos(alpha1)]])
    R2 = np.array([[np.cos(alpha2), -np.sin(alpha2)],
                   [np.sin(alpha2), np.cos(alpha2)]])
    R3 = np.array([[np.cos(alpha3), -np.sin(alpha3)],
                   [np.sin(alpha3), np.cos(alpha3)]])
    RP = np.array([[np.cos(alphap), -np.sin(alphap)],
                   [np.sin(alphap), np.cos(alphap)]])
    J1 = np.matmul(np.matmul(R1, W4), np.transpose(R1))
    J2 = np.matmul(np.matmul(R2, W4), np.transpose(R2))
    J3 = np.matmul(np.matmul(R3, W2), np.transpose(R3))
    JP = np.matmul(np.matmul(RP, WP), np.transpose(RP))

    # transfer function
    Transf = np.matmul(np.matmul(np.matmul(J1, JP), J2), J3)

    urnd = np.zeros([Rnd, n], dtype=complex)
    vrnd = np.zeros([Rnd, n], dtype=complex)
    t_dis = t_dis.reshape(n, )
    energy = np.zeros([1, Rnd])

    # definition of the rhs of the ode
    def mlock_CNLS_rhs(ts, uvt):
        [ut_rhs, vt_rhs] = np.split(uvt, 2)
        u = np.fft.ifft(ut_rhs)
        v = np.fft.ifft(vt_rhs)
        # calculation of the energy function
        E = np.trapz(np.conj(u) * u + np.conj(v) * v, t_dis)

        # u of the rhs
        urhs = -1j * 0.5 * D * (k ** 2) * ut_rhs - 1j * K * ut_rhs + \
               1j * np.fft.fft((np.conj(u) * u + (2 / 3) * np.conj(v) * v) * u + \
                               (1 / 3) * (v ** 2) * np.conj(u)) + \
               2 * g0 / (1 + E / E0) * (1 - tau * (k ** 2)) * ut_rhs - Gamma * ut_rhs

        # v of the rhs
        vrhs = -1j * 0.5 * D * (k ** 2) * vt_rhs + 1j * K * vt_rhs + \
               1j * np.fft.fft((np.conj(v) * v + (2 / 3) * np.conj(u) * u) * v + \
                               (1 / 3) * (u ** 2) * np.conj(v)) + \
               2 * g0 / (1 + E / E0) * (1 - tau * (k ** 2)) * vt_rhs - Gamma * vt_rhs

        return np.concatenate((urhs, vrhs), axis=0)

    # definition of the solution output for the ode integration
    def solout(t, y):
        ts.append(t)
        ys.append(y.copy())

    start = time.time()

    uv_list = []
    norms = []
    change_norm = 100
    jrnd = 0
    # solving the ode for Rnd rounds
    while (jrnd < Rnd and change_norm > 1e-6):
        ts = []
        ys = []

        t0 = Z * jrnd
        tend = Z * (jrnd + 1)

        uvtsol = complex_ode(mlock_CNLS_rhs)
        uvtsol.set_integrator(method='adams', name='dop853')  # alternative 'dopri5'
        uvtsol.set_solout(solout)
        uvtsol.set_initial_value(uvt, t0)
        sol = uvtsol.integrate(tend)
        assert_equal(ts[0], t0)
        assert_equal(ts[-1], tend)

        u = np.fft.ifft(sol[0:n])
        v = np.fft.ifft(sol[n:2 * n])

        urnd[jrnd, :] = u
        vrnd[jrnd, :] = v
        energy[0, jrnd] = np.trapz(np.abs(u) ** 2 + np.abs(v) ** 2, t_dis)

        uvplus = np.matmul(Transf, np.transpose(np.concatenate((u.reshape(n, 1),
                                                                v.reshape(n, 1)), axis=1)))
        uv_list.append(np.concatenate((uvplus[0, :],
                                       uvplus[1, :]), axis=0))

        uvt = np.concatenate((np.fft.fft(uvplus[0, :]),
                              np.fft.fft(uvplus[1, :])), axis=0)

        if jrnd > 0:
            phi = np.sqrt(np.abs(np.vstack(uv_list)[:, :n]) ** 2 + \
                          np.abs(np.vstack(uv_list)[:, n:2 * n]) ** 2)
            change_norm = np.linalg.norm((phi[-1, :] - phi[len(phi) - 2, :])) / \
                          np.linalg.norm(phi[len(phi) - 2, :])
            norms.append(change_norm)

        jrnd += 1

    kur = np.abs(np.fft.fftshift(np.fft.fft(phi[-1, :])))
    # M4 = kurtosis(kur)
    M4 = moment(kur, 4) / np.std(kur) ** 4

    end = time.time()
    print(end - start)

    E = np.sqrt(np.trapz(phi[-1, :] ** 2, t_dis))

    states = np.array([E, M4, alpha1, alpha2, alpha3, alphap])
    return (uvt,states)

def sech(x):
    # definition of the sech-function
    return np.cosh(x)**(-1)

class LaserSimulationEnv(gym.Env):
    def __init__(self):
        super(LaserSimulationEnv, self).__init__()

        # Define the observation space
        self.observation_space = spaces.Box(low=-np.pi/2, high=np.pi/2, shape=(4,), dtype=np.float32)

        # Define the action space
        self.action_space = spaces.Box(low=-1, high=1, shape=(4,), dtype=np.float32)


        # Define the action space low and high values
       

        # Other initialization code...
        alpha1 = -15*np.pi / 180
        alpha2 = -5*np.pi / 180
        alpha3 = 20*np.pi / 180
        alphap = 84*np.pi / 180
        self.state = [alpha1,alpha2,alpha3,alphap]
        self.steps = 0
        self.total_reward = 0

    def step(self, action ):
        
        action1 = action[0]*np.pi / 90
        action2 = action[1]*np.pi / 90
        action3 = action[2]*np.pi / 90
        action4 = action[3]*np.pi / 90

        print(action[0],action[1],action[2],action[3])
        self.state[0] += action1
        while self.state[0] > np.pi/2:
            self.state[0] -= np.pi
        while self.state[0] < -np.pi/2:
            self.state[0] += np.pi

        a=self.state[0]

        self.state[1] += action2
        while self.state[1] > np.pi/2:
            self.state[1] -= np.pi
        while self.state[1] < -np.pi/2:
            self.state[1] += np.pi

        b=self.state[1]

        self.state[2] += action3
        while self.state[2] > np.pi/2:
              self.state[2] -= np.pi
        while self.state[2] < -np.pi/2:
              self.state[2] += np.pi

        c=self.state[2]

        self.state[3] += action4
        while self.state[3] > np.pi/2:
              self.state[3] -= np.pi
        while self.state[3] < -np.pi/2:
              self.state[3] += np.pi

        d=self.state[3]
        
    


        T = 60
        n = 256
        t2 = np.linspace(-T/2,T/2,n+1)
        t_dis = t2[0:n].reshape([1,n])
        u = 0.5*np.reshape(sech(t_dis/2), [n,])   # orthogonally polarized electric field 
        v = 0.5*np.reshape(sech(t_dis/2), [n,])   # envelopes in the optical fiber

        ut=np.fft.fft(u).reshape(n,)        # fast fourier transformation of the
        vt=np.fft.fft(v).reshape(n,)        # electrical fields
        uvt=np.concatenate([ut, vt], axis=0)# concatenation of ut and vt
        (uvt_cur,states) = laser_simulation(uvt, a, b, c, d, 0.1)
        x = states[0] / states[1] - 0.1
        # Calculate the reward and done flag (modify as needed)
        reward = x
        print('Laser states: %s, reward: %s' % (', '.join(map(str, states)), x + 0.1))
        # print('Laser states: %s, reward: %s' % (states, states[0]/states[1]))
        with open('output.txt', 'a') as f:
            # f.write('Laser states: %s, reward: %s\n' % (states, states[0]/states[1]))
            f.write('Laser states: %s, reward: %s\n' % (', '.join(map(str, states)), x + 0.1))
        self.steps += 1
        self.total_reward = reward + 0.1 + self.total_reward
        if self.steps >= 30:
            done = True
            with open('total_rewards.txt', 'a') as f:
                f.write('Total reward for episode: %s\n' % self.total_reward)
            self.total_reward = 0
            self.steps = 0
            self.state = [-15 * np.pi / 180, -5 * np.pi / 180, 20 * np.pi / 180, 84 * np.pi / 180]
        else:
            done = False

        # Return the observation, reward, done flag, and additional info
        observation = np.array([a, b, c, d], dtype=np.float32)
        return observation, reward, done, {}
    def seed(self, seed=None):
        np.random.seed(seed)
    def reset(self):

        a1 = -15 * np.pi / 180
        a2 = -5 * np.pi / 180
        a3 = 20 * np.pi / 180
        ap = 84 * np.pi / 180

        self.state = [a1,a2,a3,ap]
    

        observation = np.array([a1,a2,a3,ap], dtype=np.float32)
        return observation

    def render(self, mode='human'):
        # Render the environment (optional)
        return None

    def close(self):
        # Clean up resources (if any)
        return None

env = LaserSimulationEnv()

class ReplayBuffer:
    def __init__(self, max_size, state_dim, action_dim, batch_size):
        self.mem_size = max_size
        self.batch_size = batch_size
        self.mem_cnt = 0

        self.state_memory = np.zeros((max_size, state_dim))
        self.action_memory = np.zeros((max_size, action_dim))
        self.reward_memory = np.zeros((max_size, ))
        self.next_state_memory = np.zeros((max_size, state_dim))
        self.terminal_memory = np.zeros((max_size, ), dtype=bool)

    def store_transition(self, state, action, reward, state_, done):
        mem_idx = self.mem_cnt % self.mem_size

        self.state_memory[mem_idx] = state
        self.action_memory[mem_idx] = action
        self.reward_memory[mem_idx] = reward
        self.next_state_memory[mem_idx] = state_
        self.terminal_memory[mem_idx] = done

        self.mem_cnt += 1

    def sample_buffer(self):
        mem_len = min(self.mem_cnt, self.mem_size)
        batch = np.random.choice(mem_len, self.batch_size, replace=False)

        states = self.state_memory[batch]
        actions = self.action_memory[batch]
        rewards = self.reward_memory[batch]
        states_ = self.next_state_memory[batch]
        terminals = self.terminal_memory[batch]

        return states, actions, rewards, states_, terminals

    def ready(self):
        return self.mem_cnt >= self.batch_size


class ActorNetwork(nn.Module):
    def __init__(self, alpha, state_dim, action_dim, fc1_dim, fc2_dim):
        super(ActorNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, fc1_dim)
        self.ln1 = nn.LayerNorm(fc1_dim)
        self.fc2 = nn.Linear(fc1_dim, fc2_dim)
        self.ln2 = nn.LayerNorm(fc2_dim)
        self.action = nn.Linear(fc2_dim, action_dim)

        self.optimizer = optim.Adam(self.parameters(), lr=alpha)
        self.to(device)

    def forward(self, state):
        x = T.relu(self.ln1(self.fc1(state)))
        x = T.relu(self.ln2(self.fc2(x)))
        action = T.tanh(self.action(x))

        return action

    def save_checkpoint(self, checkpoint_file):
        T.save(self.state_dict(), checkpoint_file, _use_new_zipfile_serialization=False)

    def load_checkpoint(self, checkpoint_file):
        self.load_state_dict(T.load(checkpoint_file))


class CriticNetwork(nn.Module):
    def __init__(self, beta, state_dim, action_dim, fc1_dim, fc2_dim):
        super(CriticNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim+action_dim, fc1_dim)
        self.ln1 = nn.LayerNorm(fc1_dim)
        self.fc2 = nn.Linear(fc1_dim, fc2_dim)
        self.ln2 = nn.LayerNorm(fc2_dim)
        self.q = nn.Linear(fc2_dim, 1)

        self.optimizer = optim.Adam(self.parameters(), lr=beta)
        self.to(device)

    def forward(self, state, action):
        x = T.cat([state, action], dim=-1)
        x = T.relu(self.ln1(self.fc1(x)))
        x = T.relu(self.ln2(self.fc2(x)))
        q = self.q(x)

        return q

    def save_checkpoint(self, checkpoint_file):
        T.save(self.state_dict(), checkpoint_file, _use_new_zipfile_serialization=False)

    def load_checkpoint(self, checkpoint_file):
        self.load_state_dict(T.load(checkpoint_file))

class TD3:
    def __init__(self, alpha, beta, state_dim, action_dim, actor_fc1_dim, actor_fc2_dim,
                 critic_fc1_dim, critic_fc2_dim, ckpt_dir, gamma=0.99, tau=0.005, action_noise=0.1,
                 policy_noise=0.2, policy_noise_clip=0.5, delay_time=2, max_size=100000,
                 batch_size=256):
        self.gamma = gamma
        self.tau = tau
        self.action_noise = action_noise
        self.policy_noise = policy_noise
        self.policy_noise_clip = policy_noise_clip
        self.delay_time = delay_time
        self.update_time = 0
        self.checkpoint_dir = ckpt_dir

        self.actor = ActorNetwork(alpha=alpha, state_dim=state_dim, action_dim=action_dim,
                                  fc1_dim=actor_fc1_dim, fc2_dim=actor_fc2_dim)
        self.critic1 = CriticNetwork(beta=beta, state_dim=state_dim, action_dim=action_dim,
                                     fc1_dim=critic_fc1_dim, fc2_dim=critic_fc2_dim)
        self.critic2 = CriticNetwork(beta=beta, state_dim=state_dim, action_dim=action_dim,
                                     fc1_dim=critic_fc1_dim, fc2_dim=critic_fc2_dim)

        self.target_actor = ActorNetwork(alpha=alpha, state_dim=state_dim, action_dim=action_dim,
                                         fc1_dim=actor_fc1_dim, fc2_dim=actor_fc2_dim)
        self.target_critic1 = CriticNetwork(beta=beta, state_dim=state_dim, action_dim=action_dim,
                                            fc1_dim=critic_fc1_dim, fc2_dim=critic_fc2_dim)
        self.target_critic2 = CriticNetwork(beta=beta, state_dim=state_dim, action_dim=action_dim,
                                            fc1_dim=critic_fc1_dim, fc2_dim=critic_fc2_dim)

        self.memory = ReplayBuffer(max_size=max_size, state_dim=state_dim, action_dim=action_dim,
                                   batch_size=batch_size)

        self.update_network_parameters(tau=1.0)

    def update_network_parameters(self, tau=None):
        if tau is None:
            tau = self.tau

        for actor_params, target_actor_params in zip(self.actor.parameters(),
                                                     self.target_actor.parameters()):
            target_actor_params.data.copy_(tau * actor_params + (1 - tau) * target_actor_params)

        for critic1_params, target_critic1_params in zip(self.critic1.parameters(),
                                                         self.target_critic1.parameters()):
            target_critic1_params.data.copy_(tau * critic1_params + (1 - tau) * target_critic1_params)

        for critic2_params, target_critic2_params in zip(self.critic2.parameters(),
                                                         self.target_critic2.parameters()):
            target_critic2_params.data.copy_(tau * critic2_params + (1 - tau) * target_critic2_params)

    def remember(self, state, action, reward, state_, done):
        self.memory.store_transition(state, action, reward, state_, done)

    def choose_action(self, observation, train=True):
        self.actor.eval()
        state = T.tensor([observation], dtype=T.float).to(device)
        action = self.actor.forward(state)

        if train:
            # exploration noise
            noise = T.tensor(np.random.normal(loc=0.0, scale=self.action_noise),
                             dtype=T.float).to(device)
            action = T.clamp(action+noise, -1, 1)
        self.actor.train()

        return action.squeeze().detach().cpu().numpy()

    def learn(self):
        if not self.memory.ready():
            return

        states, actions, rewards, states_, terminals = self.memory.sample_buffer()
        states_tensor = T.tensor(states, dtype=T.float).to(device)
        actions_tensor = T.tensor(actions, dtype=T.float).to(device)
        rewards_tensor = T.tensor(rewards, dtype=T.float).to(device)
        next_states_tensor = T.tensor(states_, dtype=T.float).to(device)
        terminals_tensor = T.tensor(terminals).to(device)

        with T.no_grad():
            next_actions_tensor = self.target_actor.forward(next_states_tensor)
            action_noise = T.tensor(np.random.normal(loc=0.0, scale=self.policy_noise),
                                    dtype=T.float).to(device)
            # smooth noise
            action_noise = T.clamp(action_noise, -self.policy_noise_clip, self.policy_noise_clip)
            next_actions_tensor = T.clamp(next_actions_tensor+action_noise, -1, 1)
            q1_ = self.target_critic1.forward(next_states_tensor, next_actions_tensor).view(-1)
            q2_ = self.target_critic2.forward(next_states_tensor, next_actions_tensor).view(-1)
            q1_[terminals_tensor] = 0.0
            q2_[terminals_tensor] = 0.0
            critic_val = T.min(q1_, q2_)
            target = rewards_tensor + self.gamma * critic_val
        q1 = self.critic1.forward(states_tensor, actions_tensor).view(-1)
        q2 = self.critic2.forward(states_tensor, actions_tensor).view(-1)

        critic1_loss = F.mse_loss(q1, target.detach())
        critic2_loss = F.mse_loss(q2, target.detach())
        critic_loss = critic1_loss + critic2_loss
        self.critic1.optimizer.zero_grad()
        self.critic2.optimizer.zero_grad()
        critic_loss.backward()
        self.critic1.optimizer.step()
        self.critic2.optimizer.step()

        self.update_time += 1
        if self.update_time % self.delay_time != 0:
            return

        new_actions_tensor = self.actor.forward(states_tensor)
        q1 = self.critic1.forward(states_tensor, new_actions_tensor)
        actor_loss = -T.mean(q1)
        self.actor.optimizer.zero_grad()
        actor_loss.backward()
        self.actor.optimizer.step()

        self.update_network_parameters()

    def save_models(self, episode):
        self.actor.save_checkpoint(self.checkpoint_dir + 'Actor/TD3_actor_{}.pth'.format(episode))
        print('Saving actor network successfully!')
        self.target_actor.save_checkpoint(self.checkpoint_dir +
                                          'Target_actor/TD3_target_actor_{}.pth'.format(episode))
        print('Saving target_actor network successfully!')
        self.critic1.save_checkpoint(self.checkpoint_dir + 'Critic1/TD3_critic1_{}.pth'.format(episode))
        print('Saving critic1 network successfully!')
        self.target_critic1.save_checkpoint(self.checkpoint_dir +
                                            'Target_critic1/TD3_target_critic1_{}.pth'.format(episode))
        print('Saving target critic1 network successfully!')
        self.critic2.save_checkpoint(self.checkpoint_dir + 'Critic2/TD3_critic2_{}.pth'.format(episode))
        print('Saving critic2 network successfully!')
        self.target_critic2.save_checkpoint(self.checkpoint_dir +
                                            'Target_critic2/TD3_target_critic2_{}.pth'.format(episode))
        print('Saving target critic2 network successfully!')

    def load_models(self, episode):
        self.actor.load_checkpoint(self.checkpoint_dir + 'Actor/TD3_actor_{}.pth'.format(episode))
        print('Loading actor network successfully!')
        self.target_actor.load_checkpoint(self.checkpoint_dir +
                                          'Target_actor/TD3_target_actor_{}.pth'.format(episode))
        print('Loading target_actor network successfully!')
        self.critic1.load_checkpoint(self.checkpoint_dir + 'Critic1/TD3_critic1_{}.pth'.format(episode))
        print('Loading critic1 network successfully!')
        self.target_critic1.load_checkpoint(self.checkpoint_dir +
                                            'Target_critic1/TD3_target_critic1_{}.pth'.format(episode))
        print('Loading target critic1 network successfully!')
        self.critic2.load_checkpoint(self.checkpoint_dir + 'Critic2/TD3_critic2_{}.pth'.format(episode))
        print('Loading critic2 network successfully!')
        self.target_critic2.load_checkpoint(self.checkpoint_dir +
                                            'Target_critic2/TD3_target_critic2_{}.pth'.format(episode))
        print('Loading target critic2 network successfully!')

def main():
    env = LaserSimulationEnv()
    env_name = 'envNPR-v0'
    agent = TD3(alpha=0.0002, beta=0.0002, state_dim=4,
                action_dim=4, actor_fc1_dim=400, actor_fc2_dim=300,
                critic_fc1_dim=400, critic_fc2_dim=300, ckpt_dir=args.ckpt_dir, gamma=0.99,
                tau=0.005, action_noise=0.1, policy_noise=0.2, policy_noise_clip=0.5,
                delay_time=4, max_size=100000, batch_size=8)
    create_directory(path=args.ckpt_dir, sub_path_list=['Actor', 'Critic1', 'Critic2', 'Target_actor',
                                                        'Target_critic1', 'Target_critic2'])

    total_reward_history = []
    avg_reward_history = []
    for episode in range(args.max_episodes):
        total_reward = 0
        done = False
        observation = env.reset()

        while not done :
            action = agent.choose_action(observation, train=True)
            action_ = scale_action(action, low=env.action_space.low, high=env.action_space.high)
            observation_, reward, done, info = env.step(action_)
            agent.remember(observation, action, reward, observation_, done)
            agent.learn()
            total_reward += reward
            observation = observation_

        total_reward_history.append(total_reward)
        avg_reward = np.mean(total_reward_history[-100:])
        avg_reward_history.append(avg_reward)
        print('Ep: {} Reward: {} AvgReward: {}'.format(episode+1, total_reward, avg_reward))
        with open('another_output.txt', 'a') as f:
             f.write('Ep: {} Reward: {} AvgReward: {}\n'.format(episode + 1, total_reward, avg_reward))
        if (episode + 1) % 100 == 0:
            agent.save_models(episode+1)

    episodes = [i+1 for i in range(args.max_episodes)]
    #plot_learning_curve(episodes, avg_reward_history, title='AvgReward', ylabel='reward')#,
                        #figure_file=args.figure_file)

if __name__ == '__main__':
    main()
